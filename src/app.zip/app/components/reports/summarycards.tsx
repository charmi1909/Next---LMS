type SummaryProps = {
  summary: {
    totalBooks: number;
    totalUsers: number;
    booksBorrowed: number;
    overdue: number;
  };
};

export default function SummaryCards({ summary }: SummaryProps) {
  if (!summary) return <div>Loading summary...</div>;

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      <div className="bg-white rounded-lg shadow p-4">
        <h2 className="text-sm text-gray-500">📚 Total Books</h2>
        <p className="text-xl font-bold">{summary.totalBooks}</p>
      </div>
      <div className="bg-white rounded-lg shadow p-4">
        <h2 className="text-sm text-gray-500">👥 Total Users</h2>
        <p className="text-xl font-bold">{summary.totalUsers}</p>
      </div>
      <div className="bg-white rounded-lg shadow p-4">
        <h2 className="text-sm text-gray-500">📖 Currently Books Borrowed</h2>
        <p className="text-xl font-bold">{summary.booksBorrowed}</p>
      </div>
     
    </div>
  );
}
