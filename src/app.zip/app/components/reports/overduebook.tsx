type OverdueTableProps = {
  data: { user: string; book: string; daysOverdue: number }[];
};

export default function OverdueTable({ data }: OverdueTableProps) {
  if (!data || data.length === 0) return <div>No overdue books found.</div>;

  return (
    <div className="bg-white rounded-lg shadow p-4 overflow-x-auto">
      <h2 className="text-lg font-semibold mb-4">📋 Overdue Books</h2>
      <table className="min-w-full text-sm text-left">
        <thead>
          <tr className="bg-gray-100">
            <th className="p-2">User</th>
            <th className="p-2">Book</th>
            <th className="p-2">Days Overdue</th>
          </tr>
        </thead>
        <tbody>
          {data.map((entry, i) => (
            <tr key={i} className="border-t">
              <td className="p-2">{entry.user}</td>
              <td className="p-2">{entry.book}</td>
              <td className="p-2">{entry.daysOverdue}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
