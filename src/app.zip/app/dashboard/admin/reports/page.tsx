'use client';

import { useEffect, useState } from 'react';
// Assuming SummaryCards, BorrowingTrendsChart, OverdueTable, UserRoleDistributionChart are correctly imported
import SummaryCards from '@/app/components/reports/summarycards';
import BorrowingTrendsChart from '@/app/components/reports/borrowtrendschart';
import OverdueTable from '@/app/components/reports/overduebook';
import UserRoleDistributionChart from '@/app/components/reports/userrole';

export default function ReportsDashboardPage() {
  const [reportData, setReportData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchReports() {
      try {
        const res = await fetch('/api/admin/reports/summary');
        const data = await res.json();
        setReportData(data);
      } catch (error) {
        console.error('Failed to fetch report data:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchReports();
  }, []);

  if (loading) {
    return <div className="reports-loading-message">Loading reports...</div>; // Replaced p-8
  }

  if (!reportData) {
    return <div className="reports-error-message">Failed to load report data.</div>; // Replaced p-8 text-red-500
  }

  return (
    <div className="reports-dashboard-container"> {/* Replaced p-8 */}
      <h1 className="reports-dashboard-title">📊 Reports & Analytics</h1> {/* Replaced text-3xl font-bold mb-6 */}

      {/* SummaryCards component - assume it handles its own internal cards/layout */}
      <SummaryCards summary={reportData.summary} />

      <div className="charts-grid"> {/* Replaced grid grid-cols-1 md:grid-cols-2 gap-6 mt-8 */}
        {/* These components should ideally apply 'report-section-card' to their outermost div */}
        <BorrowingTrendsChart data={reportData.borrowTrends} />
        <UserRoleDistributionChart data={reportData.userRoles} />
      </div>

      
    </div>
  );
}