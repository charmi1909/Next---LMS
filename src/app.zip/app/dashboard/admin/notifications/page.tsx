'use client';

import { useEffect, useState } from 'react';
import { formatDistanceToNow } from 'date-fns';

type Notification = {
  _id: string;
  message: string;
  type: 'login' | 'book_added' | 'info' | 'warning';
  read: boolean;
  createdAt: string;
};

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    const res = await fetch('/api/notifications');
    const data = await res.json();
    setNotifications(data);
  };

  const markAsRead = async (id: string) => {
    await fetch(`/api/notifications/${id}`, { method: 'PATCH' });
    fetchNotifications();
  };

  const deleteNotification = async (id: string) => {
    await fetch(`/api/notifications/${id}`, { method: 'DELETE' });
    fetchNotifications();
  };

  const getBadgeClass = (type: string) => {
    switch (type) {
      case 'login':
        return 'badge badge-login';
      case 'book_added':
        return 'badge badge-book';
      case 'warning':
        return 'badge badge-warning';
      default:
        return 'badge badge-info';
    }
  };

  return (
    <div className="notification-container">
      <h1>Admin Notifications</h1>

      {notifications.length === 0 ? (
        <p className="text-gray-500">No notifications found.</p>
      ) : (
        notifications.map((n) => (
          <div key={n._id} className="notification-card">
            <div>
              <p className="notification-message">{n.message}</p>
              <p className="notification-time">
                {formatDistanceToNow(new Date(n.createdAt), { addSuffix: true })}
              </p>
              <div>
                <span className={getBadgeClass(n.type)}>{n.type}</span>
                {!n.read && (
                  <span className="badge badge-unread">Unread</span>
                )}
              </div>
            </div>

            <div className="button-group">
              <button onClick={() => markAsRead(n._id)} className="button-outline">
                Mark Read
              </button>
              <button onClick={() => deleteNotification(n._id)} className="button-danger">
                Delete
              </button>
            </div>
          </div>
        ))
      )}
    </div>
  );
}
