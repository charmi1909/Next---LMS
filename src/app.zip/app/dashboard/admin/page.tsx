'use client';

import React, { useEffect, useState } from 'react';
import './admin.css';

interface UserInfo { // This interface is from the layout, not strictly needed here unless you fetch user info specific to the dashboard
  name: string;
  email: string;
  role: string;
}

export default function AdminDashboardOverviewPage() {
  const [stats, setStats] = useState({
    totalBooks: 0,
    totalPatrons: 0,
    totalLibrarians: 0,
    overdueBooks: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await fetch('/api/admin/overview');
        const data = await res.json();
        setStats(data);
      } catch (err) {
        console.error('Failed to fetch dashboard stats:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  const cards = [
    { label: 'Total Books', value: stats.totalBooks, icon: '📚' },
    { label: 'Registered Patrons', value: stats.totalPatrons, icon: '👥' },
    { label: 'Active Librarians', value: stats.totalLibrarians, icon: '🧑‍🏫' },
    { label: 'Overdue Books', value: stats.overdueBooks, icon: '⏰' },
  ];

  return (
    <div className="dashboard-page-container"> {/* New class for the main page padding */}
      <h1 className="dashboard-title">📊 Admin Dashboard</h1> {/* Styled by .dashboard-title */}

      {loading ? (
        <p className="loading-text">Loading stats...</p> 
      ) : (
        <div className="dashboard-stats-grid"> {/* Styled by .dashboard-stats-grid */}
          {cards.map((stat) => (
            <div
              key={stat.label}
              className="stat-card" // Styled by .stat-card
            >
              <div className="stat-icon">{stat.icon}</div> {/* Styled by .stat-icon */}
              <div>
                <div className="stat-label">{stat.label}</div> {/* Styled by .stat-label */}
                <div className="stat-value">{stat.value}</div> {/* Styled by .stat-value */}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}