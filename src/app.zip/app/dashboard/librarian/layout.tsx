'use client'; // Required for usePathname and useState, useEffect

import Link from 'next/link';
import './librarian.css';
import { usePathname } from 'next/navigation';
import {
  FaSignOutAlt, FaBook, FaExchangeAlt, FaUsers, FaClock, FaClipboardList, FaHome,
  FaSun, FaMoon // Icons for theme toggle
} from 'react-icons/fa';
import { useState, useEffect } from 'react'; // Import useState and useEffect for theme toggle

interface NavItemProps {
  href: string;
  icon: React.ElementType;
  label: string;
  isActive: boolean;
  isDarkMode: boolean; // Prop to indicate current theme for dot color
}

// Helper component for each navigation item
const NavItem: React.FC<NavItemProps> = ({ href, icon: Icon, label, isActive, isDarkMode }) => {
  return (
    <Link href={href} className="librarian-sidebar-nav-item">
      <div className={`librarian-sidebar-nav-item-content ${isActive ? 'active' : ''}`}>
        <Icon className="librarian-sidebar-icon" />
        <span className="librarian-sidebar-label">{label}</span>
        {/* The dot's class now correctly uses the isDarkMode prop */}
        <span className={`librarian-sidebar-dot ${isActive ? '' : (isDarkMode ? 'dark' : 'light')}`}></span>
      </div>
    </Link>
  );
};


export default function LibrarianLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  // State for theme: true for dark mode, false for light mode
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Effect to read initial theme from localStorage and apply it
  useEffect(() => {
    // Check if window is defined to ensure this runs only client-side
    if (typeof window !== 'undefined') {
      const savedTheme = localStorage.getItem('theme');
      const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;

      if (savedTheme === 'dark' || (savedTheme === null && prefersDark)) {
        document.documentElement.classList.add('dark');
        setIsDarkMode(true);
      } else {
        document.documentElement.classList.remove('dark');
        setIsDarkMode(false);
      }
    }
  }, []); // Run once on component mount

  // Function to toggle theme
  const toggleTheme = () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    if (typeof window !== 'undefined') { // Ensure window is defined before accessing localStorage
      if (newTheme) {
        document.documentElement.classList.add('dark');
        localStorage.setItem('theme', 'dark');
      } else {
        document.documentElement.classList.remove('dark');
        localStorage.setItem('theme', 'light');
      }
    }
  };

  const handleLogout = () => {
    console.log('Logging out...');
    // Implement your actual logout logic here (e.g., clearing JWT, redirecting)
    if (typeof window !== 'undefined') { // Ensure window is defined before redirecting
      window.location.href = '/auth'; // Redirect to auth page
    }
  };

  const navItems = [
    { href: '/dashboard/librarian', icon: FaHome, label: 'Dashboard' },
    { href: '/dashboard/librarian/catalog', icon: FaBook, label: 'Cataloging Management' },
    { href: '/dashboard/librarian/circulation', icon: FaExchangeAlt, label: 'Circulation Management' },
    { href: '/dashboard/librarian/patron', icon: FaUsers, label: 'Patron Management' },
    { href: '/dashboard/librarian/overdue', icon: FaClock, label: 'Overdue Management' }
  ];


  return (
    <div className="librarian-layout-container">
      {/* Sidebar */}
      <aside className="librarian-sidebar">
        <div className="librarian-sidebar-header">
          <h2>LMS</h2>
          <p>Librarian Panel</p>
        </div>
        <nav className="librarian-sidebar-nav">
          {navItems.map((item) => (
            <NavItem
              key={item.href}
              href={item.href}
              icon={item.icon}
              label={item.label}
              isActive={
                // Special handling for the base dashboard path
                item.href === '/dashboard/librarian'
                  ? pathname === '/dashboard/librarian'
                  : pathname.startsWith(item.href)
              }
              isDarkMode={isDarkMode} // Pass the dark mode state to NavItem
            />
          ))}
        </nav>
        {/* Logout Button in Sidebar */}
        <button
          onClick={handleLogout}
          className="librarian-sidebar-logout-button"
        >
          <FaSignOutAlt className="mr-2" />
          <span>Logout</span>
        </button>
        <div className="librarian-sidebar-footer">
          &copy; {new Date().getFullYear()} Library Management.
        </div>
      </aside>

      {/* Main content area */}
      <div className="librarian-content-area">
        {/* Navbar */}
        <nav className="librarian-navbar">
          <div className="librarian-navbar-container">
            <Link href="/dashboard/librarian" className="librarian-navbar-title">
              Librarian Dashboard
            </Link>
            <div className="librarian-navbar-links">
              {/* Theme Toggle Button */}
              <button
                onClick={toggleTheme}
                className="librarian-theme-toggle-button"
                aria-label="Toggle theme"
              >
                {isDarkMode ? <FaSun className="theme-icon" /> : <FaMoon className="theme-icon" />}
              </button>

              {/* Removed Logout Button from Navbar */}
              {/* <button
                onClick={handleLogout}
                className="librarian-logout-button"
              >
                <FaSignOutAlt className="mr-2" />
                <span>Logout</span>
              </button> */}
            </div>
          </div>
        </nav>

        {/* Page content */}
        <main className="librarian-main-content">
          <div className="librarian-content-card">
            {children}
          </div>
        </main>

        {/* Footer */}
        <footer className="librarian-footer">
          <div className="librarian-footer-container">
            &copy; {new Date().getFullYear()} Library Management System. All rights reserved.
          </div>
        </footer>
      </div>
    </div>
  );
}