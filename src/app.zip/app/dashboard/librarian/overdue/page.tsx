'use client';

import { useEffect, useState } from 'react';

type OverdueItem = {
  _id: string;
  bookId: string;
  fine: number;
  fineCollected: boolean;
  book: {
    title: string;
    isbn: string;
  };
  userId: {
    _id: string;
    name: string;
    email: string;
  };
  dueDate: string;
};

export default function OverduePage() {
  const [overdueItems, setOverdueItems] = useState<OverdueItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');

  const fetchOverdueItems = async () => {
    try {
      const res = await fetch('/api/overdue');
      if (!res.ok) throw new Error('Failed to fetch overdue items');
      const data = await res.json();
      setOverdueItems(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCollectFine = async (borrowId: string) => {
    try {
      const res = await fetch('/api/circulation/fines', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ borrowId }),
      });
      const data = await res.json();
      if (res.ok) {
        setMessage(`Fine collected successfully.`);
        fetchOverdueItems(); // Refresh list
      } else {
        setMessage(data.message || 'Error collecting fine.');
      }
    } catch (err) {
      setMessage('Server error collecting fine.');
    }

    setTimeout(() => setMessage(''), 3000);
  };

  useEffect(() => {
    fetchOverdueItems();
  }, []);

  return (
    <div className="overdue-page-container">
      <h1 className="overdue-title">Overdue Items</h1>

      {message && (
        <div className="overdue-message text-green-600">{message}</div>
      )}

      {loading ? (
        <p className="overdue-message">Loading overdue items...</p>
      ) : overdueItems.length === 0 ? (
        <p className="overdue-message italic">No overdue items found.</p>
      ) : (
        <div className="overdue-table-container">
          <table className="overdue-table">
            <thead className="overdue-table-header">
              <tr>
                <th className="overdue-table-th">Title</th>
                <th className="overdue-table-th">ISBN</th>
                <th className="overdue-table-th">Borrower</th>
                <th className="overdue-table-th">Due Date</th>
                <th className="overdue-table-th">Fine</th>
                <th className="overdue-table-th">Action</th>
              </tr>
            </thead>
            <tbody>
              {overdueItems.map((item) => (
                <tr key={item._id} className="overdue-table-row">
                  <td className="overdue-table-td title">{item.book?.title || 'N/A'}</td>
                  <td className="overdue-table-td isbn">
                    {item.book?.isbn || 'N/A'} <br />
                    <span className="text-xs text-gray-500">Book ID: {item.bookId}</span>
                  </td>
                  <td className="overdue-table-td">
                    {item.userId?.name || 'Unknown'}
                    <span className="overdue-table-td borrower-email">{item.userId?.email}</span>
                  </td>
                  <td className="overdue-table-td due-date">
                    {new Date(item.dueDate).toLocaleDateString()}
                  </td>
                  <td className="overdue-table-td fine-amount">
                    ₹ {item.fine?.toFixed(2) || '0.00'}
                  </td>
                  <td className="overdue-table-td action">
                    {item.fineCollected ? (
                      <span className="text-green-600 font-semibold">Fine Collected</span>
                    ) : (
                      <button
                        className="text-blue-600 underline"
                        onClick={() => handleCollectFine(item._id)}
                      >
                        Collect Fine
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
