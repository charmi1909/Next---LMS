// app/dashboard/patron/layout.tsx
"use client"; // This layout component uses client-side hooks

import { useState, useEffect } from 'react';
import Link from "next/link";
import './patron.css';
import { useRouter, usePathname } from 'next/navigation'; // usePathname to highlight active link

// Import Font Awesome icons
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faSun, faMoon,    // Theme Toggle
  faSignOutAlt,     // Logout
  faSearch,         // Search & Browse
  faBook,           // View Item Details (using faBook for a generic item)
  faUserCircle,     // Account Management
  faUserEdit,       // Profile Management (Changed to faUser for My Profile)
  faThumbtack,      // Reserve/Hold Item (could also be faBookmark)
  faBell,           // Notifications
  faHome,           // Dashboard Home
  faChevronLeft,    // Collapse/Expand icon
  faChevronRight,    // Collapse/Expand icon
  faUser // Changed from faUserEdit for My Profile
} from '@fortawesome/free-solid-svg-icons';


export default function PatronLayout({ children }: { children: React.ReactNode }) {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [notificationCount, setNotificationCount] = useState(3); // Example count for notifications
  const router = useRouter();
  const pathname = usePathname(); // Get current path for active link highlighting

  // Effect to read theme from localStorage on mount and apply it
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const savedTheme = localStorage.getItem('theme');
      if (savedTheme === 'dark') {
        setIsDarkMode(true);
        document.documentElement.setAttribute('data-theme', 'dark'); // Use data-theme attribute
      } else {
        setIsDarkMode(false);
        document.documentElement.setAttribute('data-theme', 'light'); // Use data-theme attribute
      }
    }
  }, []);

  // Function to toggle theme (light/dark mode)
  const toggleTheme = () => {
    if (typeof window !== 'undefined') {
      const newTheme = !isDarkMode;
      setIsDarkMode(newTheme);
      if (newTheme) {
        document.documentElement.setAttribute('data-theme', 'dark');
        localStorage.setItem('theme', 'dark');
      } else {
        document.documentElement.setAttribute('data-theme', 'light');
        localStorage.setItem('theme', 'light');
      }
    }
  };

  // Function to toggle sidebar collapse
  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  // Handle Logout action, navigating to the /auth path
  const handleLogout = () => {
    // In a real application, you would also clear authentication tokens or session data here
    router.push('/auth');
  };

  return (
    // Applied patron-dashboard-layout and collapsed class conditionally
    <div className={`patron-dashboard-layout ${isSidebarCollapsed ? 'collapsed' : ''}`}>
      {/* Sidebar */}
      <aside className="patron-sidebar">
        <div className="patron-sidebar-header">
          <button className="sidebar-toggle-button" onClick={toggleSidebar} aria-label="Toggle sidebar">
            <FontAwesomeIcon icon={isSidebarCollapsed ? faChevronRight : faChevronLeft} />
          </button>
          {!isSidebarCollapsed && (
            <h2 className="patron-sidebar-title">📚Module</h2>
          )}
        </div>
        <nav className="patron-sidebar-nav">
          {/* Using <ul> for semantic list, though not strictly required by CSS here */}
          <ul>
            {[
              { name: 'Dashboard', href: '/dashboard/patron', icon: faHome },
              { name: 'Search & Browse', href: '/dashboard/patron/search', icon: faSearch },
              { name: 'View All Items', href: '/dashboard/patron/item', icon: faBook },
              { name: 'Account Management', href: '/dashboard/patron/account', icon: faUserCircle },
              { name: 'Reserve/Hold Item', href: '/dashboard/patron/holds', icon: faThumbtack },
              { name: 'Return Borrow Items', href: '/dashboard/patron/return', icon: faBook },
              { name: 'My Profile', href: '/dashboard/patron/profile', icon: faUser }, // Changed icon to faUser
            ].map((item) => (
              <li key={item.name}> {/* Wrap Link in <li> for semantic list */}
                <Link
                  href={item.href}
                  className={`sidebar-nav-item ${pathname === item.href ? 'active' : ''}`}
                >
                  <FontAwesomeIcon icon={item.icon} className="sidebar-icon" />
                  <span className="sidebar-text">{item.name}</span>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        {/* User / Avatar at the bottom of sidebar - Remove this comment if you want to add content here */}
      </aside>

      {/* Main Content Area */}
      <div className="patron-main-content-wrapper">
        {/* Header */}
        <header className="patron-header">
          <div className="patron-header-left">
            {/* This button toggles the sidebar, just like the one in the sidebar header */}
            <button className="header-action-button sidebar-toggle-button" onClick={toggleSidebar} aria-label="Toggle sidebar">
              <FontAwesomeIcon icon={isSidebarCollapsed ? faChevronRight : faChevronLeft} />
            </button>
            <h1 className="patron-header-title">Patron Dashboard</h1>
          </div>
          <div className="patron-header-actions">
            {/* Theme Toggle Button */}
            <button
              onClick={toggleTheme}
              className="header-action-button"
              aria-label={isDarkMode ? "Switch to light mode" : "Switch to dark mode"}
            >
              <FontAwesomeIcon icon={isDarkMode ? faSun : faMoon} className="header-icon" />
            </button>

            {/* Notifications Icon with Badge */}
            


            {/* Logout Button */}
            <button
              onClick={handleLogout}
              className="header-action-button"
              aria-label="Logout"
            >
              <FontAwesomeIcon icon={faSignOutAlt} className="header-icon" />
            </button>
          </div>
        </header>

        {/* Dynamic Page Content (Children) */}
        <main className="patron-main-content-body">
          {children} {/* This is where your actual page content will be rendered */}
        </main>

        {/* Footer */}
        <footer className="patron-footer">
          &copy; {new Date().getFullYear()} Library Patron Module. All rights reserved.
        </footer>
      </div>
    </div>
  );
}