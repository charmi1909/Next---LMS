'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';

interface BorrowRecord {
  _id: string;
  bookId: {
    title: string;
    author: string;
  };
  borrowedAt: string;
  returnedAt?: string;
  dueDate: string;
  fine?: number;
}

// Custom Message Modal Component (Ensure this matches your latest version or use this one)
const MessageModal: React.FC<{
  message: string | null;
  type: 'success' | 'error' | 'info';
  onClose: () => void;
}> = ({ message, type, onClose }) => {
  if (!message) return null;

  let contentBgClass = '';
  let headerColorClass = '';

  if (type === 'success') {
    contentBgClass = 'message-modal-success-bg';
    headerColorClass = 'message-modal-success-text';
  } else if (type === 'error') {
    contentBgClass = 'message-modal-error-bg';
    headerColorClass = 'message-modal-error-text';
  } else if (type === 'info') {
    contentBgClass = 'message-modal-info-bg';
    headerColorClass = 'message-modal-info-text';
  }

  return (
    <div className="message-modal-overlay">
      <div className={`message-modal-content ${contentBgClass}`}>
        <div className="message-modal-header">
          <h3 className={`message-modal-title ${headerColorClass}`}>
            {type === 'success' ? 'Success!' : type === 'error' ? 'Error!' : 'Info'}
          </h3>
          <button onClick={onClose} className="message-modal-close-btn">&times;</button>
        </div>
        <p className="message-modal-body">{message}</p>
        <div className="message-modal-actions">
          <button
            onClick={onClose}
            className="message-modal-ok-btn"
          >
            OK
          </button>
        </div>
      </div>
    </div>
  );
};


export default function AccountManagementPage() {
  const [records, setRecords] = useState<BorrowRecord[]>([]);
  const [totalFines, setTotalFines] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null); // New toast state
  const [messageModal, setMessageModal] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null); // Renamed from 'message' for clarity

  const closeMessageModal = () => setMessageModal(null);
  const showToast = (message: string, type: 'success' | 'error') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };


  useEffect(() => {
  const fetchAccountData = async () => {
    setLoading(true);
    setError(null);
    try {
      // ✅ Fetch borrow history
      const historyRes = await fetch('/api/patron/account/history', { credentials: 'include' });
      const historyText = await historyRes.text();

      let historyData;
      try {
        historyData = JSON.parse(historyText);
      } catch {
        setError('Invalid history data format');
        setMessageModal({ text: 'Invalid history data format', type: 'error' });
        setLoading(false);
        return;
      }

      if (historyRes.ok && historyData.success) {
        const formattedHistory = historyData.history.map((record: any) => ({
          ...record,
          returnedAt: record.returnedAt ? new Date(record.returnedAt) : null, // ✅ Format returnedAt safely
        }));
        setRecords(formattedHistory);
      } else {
        throw new Error(historyData.message || 'Failed to fetch history');
      }

      // ✅ Fetch fines
      const finesRes = await fetch('/api/patron/account/fines', { credentials: 'include' });
      const finesText = await finesRes.text();

      let finesData;
      try {
        finesData = JSON.parse(finesText);
      } catch {
        setError('Invalid fines data format');
        setMessageModal({ text: 'Invalid fines data format', type: 'error' });
        setLoading(false);
        return;
      }

      if (finesRes.ok && finesData.success) {
        setTotalFines(finesData.totalFines || 0);
      } else {
        throw new Error(finesData.message || 'Failed to fetch fines');
      }

    } catch (err: any) {
      setError(err.message);
      setMessageModal({ text: err.message, type: 'error' });
      showToast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  fetchAccountData();
}, []);


  const currentItems = records.filter(r => !r.returnedAt);

  return (
    <div className="account-management-page"> {/* Main page container class */}
      {/* Google Font Import for 'Inter' - Better managed globally */}
      <style>
        {`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
        body { font-family: 'Inter', sans-serif; }
        `}
      </style>

      {/* Toast Notification Component */}
      {toast && (
        <div
          className={`toast-notification ${toast.type === 'success' ? 'toast-success' : 'toast-error'}`}
        >
          {toast.message}
        </div>
      )}

      <div className="account-content-wrapper"> {/* Content wrapper class */}
        <h1 className="account-page-heading">Account Management</h1>

        {loading && <p className="loading-message">Loading account data...</p>}
        {error && (
            <div className="error-card">
              <p className="error-title">Error!</p>
              <p className="error-message">{error}</p>
              {/* Optional: Add a retry button here if applicable */}
            </div>
        )}

        {!loading && !error && (
          <>
            <section className="reserve-info-card"> {/* Existing custom class */}
              <p className="text-lg mb-2">Want to place a hold on a book that's currently borrowed?</p>
              <p className="text-md">
                You can do this from the{' '}
                <Link href="/dashboard/patron/item" className="link-text"> {/* Use custom link class */}
                  All Books
                </Link>{' '}
                page.
              </p>
            </section>

            {/* Current Borrowed Items */}
            <section className="account-section-card"> {/* New custom class for sections */}
              <h2 className="account-section-heading">Current Borrowed Items</h2>
              {currentItems.length === 0 ? (
                <p className="no-items-message">No currently borrowed items.</p>
              ) : (
                <ul className="borrow-records-list"> {/* New custom class for lists */}
                  {currentItems.map((record) => (
                    <li key={record._id} className="borrow-record-item"> {/* New custom class for list items */}
                      <p className="item-title"><strong>Title:</strong> {record.bookId?.title || 'N/A'}</p>
                      <p className="item-author"><strong>Author:</strong> {record.bookId?.author || 'N/A'}</p>
                      <p className="item-date"><strong>Borrowed At:</strong> {new Date(record.borrowedAt).toLocaleDateString()}</p>
                      <p className="item-date"><strong>Due Date:</strong> {new Date(record.dueDate).toLocaleDateString()}</p>
                    </li>
                  ))}
                </ul>
              )}
            </section>

            {/* Borrowing History */}
            <section className="account-section-card">
              <h2 className="account-section-heading">Borrowing History</h2>
              {records.length === 0 ? (
                <p className="no-items-message">No borrowing history found.</p>
              ) : (
                <ul className="borrow-records-list">
                  {records.map((record) => (
                    <li key={record._id} className="borrow-record-item">
                      <p className="item-title"><strong>Title:</strong> {record.bookId?.title || 'N/A'}</p>
                      <p className="item-author"><strong>Author:</strong> {record.bookId?.author || 'N/A'}</p>
                      <p className="item-date"><strong>Borrowed At:</strong> {new Date(record.borrowedAt).toLocaleDateString()}</p>
                      <p className="item-date"><strong>Returned At:</strong> {record.returnedAt ? new Date(record.returnedAt).toLocaleDateString() : 'Not returned'}</p>
                      {record.fine && record.fine > 0 && (
                        <p className="fine-text"><strong>Fine:</strong> ₹{record.fine.toFixed(2)}</p>
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </section>

            {/* Fines Summary */}
            <section className="account-section-card">
              <h2 className="account-section-heading">Total Outstanding Fines</h2>
              <p className={`fines-summary-text ${totalFines > 0 ? 'fine-text-total' : 'no-fine-text'}`}> {/* New fine text classes */}
                ₹{totalFines.toFixed(2)}
              </p>
            </section>
          </>
        )}

        <MessageModal
          message={messageModal?.text || null}
          type={messageModal?.type || 'info'}
          onClose={closeMessageModal}
        />
      </div>
    </div>
  );
}