'use client';

import React, { useEffect, useState } from 'react';
import './patron.css';

export default function PatronDashboardPage() {
  const [name, setName] = useState('');
  const [totalBorrowed, setTotalBorrowed] = useState(0);
  const [currentBorrowed, setCurrentBorrowed] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchProfileAndStats = async () => {
      try {
        setLoading(true);
        setError('');

        const profileRes = await fetch('/api/user/profile', {
          method: 'GET',
          credentials: 'include', // ✅ send JWT cookie
        });
        if (!profileRes.ok) throw new Error('Failed to fetch profile');
        const profileData = await profileRes.json();
        setName(profileData.name || 'User');

        const statsRes = await fetch('/api/user/borrowStats', {
          method: 'GET',
          credentials: 'include', // ✅ send JWT cookie
        });
        if (!statsRes.ok) throw new Error('Failed to fetch borrow stats');
        const statsData = await statsRes.json();
        setTotalBorrowed(statsData.total || 0);
        setCurrentBorrowed(statsData.current || 0);
      } catch (err) {
        console.error('Error loading dashboard data:', err);
        setError('Failed to load dashboard data. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    fetchProfileAndStats();
  }, []);

  if (loading) {
    return (
      <div className="patron-dashboard">
        <div className="loading">
          <div className="loading-spinner"></div>
        </div>
      </div>
    );
  }

  // ... (imports and state remain the same) ...

// No changes needed within the stat-card structure,
// as we'll style the existing strong and span elements differently.

return (
  <div className="patron-dashboard">
    <h1>Welcome, {name}!</h1>

    {error && <div className="error-message">{error}</div>}

    <div className="patron-stats-layout-2"> {/* New class for this layout */}
      <div className="stat-card">
        <div className="stat-icon-wrapper">
          <i className="fas fa-book"></i> {/* Example icon for books */}
        </div>
        <div className="stat-content">
          <strong>Total Books Borrowed</strong>
          <span className="stat-number">{totalBorrowed}</span>
        </div>
      </div>

      <div className="stat-card">
        <div className="stat-icon-wrapper">
          <i className="fas fa-clipboard-list"></i> {/* Example icon for currently borrowed */}
        </div>
        <div className="stat-content">
          <strong>Currently Borrowed</strong>
          <span className="stat-number">{currentBorrowed}</span>
        </div>
      </div>
    </div>
  </div>
);
}
