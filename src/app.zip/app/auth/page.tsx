'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import './auth.css';
const LIBRARIAN_SECRET = 'charmi19'; 




export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    address: '',
    dob: '',
    role: 'patron',
  });
  const [message, setMessage] = useState('');
  const [showLibrarianCodePrompt, setShowLibrarianCodePrompt] = useState(false);
  const [tempUserData, setTempUserData] = useState<any>(null);
  const [librarianCode, setLibrarianCode] = useState('');

  const router = useRouter();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    setMessage('');

    try {
      const endpoint = isLogin ? '/api/auth/login' : '/api/auth/register';
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });

      const data = await res.json();

      if (res.ok) {
        if (isLogin) {
          if (data.user.role === 'librarian') {
            setTempUserData(data.user);
            setShowLibrarianCodePrompt(true);
          } else if (data.user.role === 'admin') {
            router.push('/dashboard/admin');
          } else {
            router.push('/dashboard/patron');
          }
        } else {
          setIsLogin(true);
          setMessage('Registration successful! Please login.');
          setForm({
            name: '',
            email: '',
            password: '',
            phone: '',
            address: '',
            dob: '',
            role: 'patron',
          });
        }
      } else {
        setMessage(data.error || 'An error occurred. Please try again.');
      }
    } catch (error) {
      console.error('Authentication error:', error);
      setMessage('Network error or server issue. Please try again later.');
    }
  };

  const verifyLibrarianCode = () => {
  const correctCode = process.env.NEXT_PUBLIC_LIBRARIAN_CODE || 'charmi19';

  if (librarianCode.trim() === correctCode) {
    router.push('/dashboard/librarian');
  } else {
    setMessage('❌ Invalid librarian secret code!');
  }
};


  return (
    <div className="auth-wrapper">
      <div className="auth-card">
        <h2>{isLogin ? 'Login' : 'Sign Up'}</h2>

        {!isLogin && (
          <>
            <div className="input-group">
              <input
                name="name"
                placeholder="Your Name"
                value={form.name}
                onChange={handleChange}
                required
              />
              <span className="input-icon">🧑</span>
            </div>

            <div className="input-group">
              <input
                name="phone"
                placeholder="Contact Number"
                value={form.phone}
                onChange={handleChange}
              />
              <span className="input-icon">📞</span>
            </div>

            <div className="input-group">
              <input
                name="address"
                placeholder="Address"
                value={form.address}
                onChange={handleChange}
              />
              <span className="input-icon">🏠</span>
            </div>

            <div className="input-group">
              <input
                name="dob"
                type="date"
                placeholder="Date of Birth"
                value={form.dob}
                onChange={handleChange}
              />
              <span className="input-icon">🎂</span>
            </div>
          </>
        )}

        <div className="input-group">
          <input
            name="email"
            placeholder="Email"
            type="email"
            value={form.email}
            onChange={handleChange}
            required
          />
          <span className="input-icon">📧</span>
        </div>

        <div className="input-group">
          <input
            name="password"
            placeholder="Password"
            type="password"
            value={form.password}
            onChange={handleChange}
            required
          />
          <span className="input-icon">🔒</span>
        </div>

        {!isLogin && (
          <div className="input-group">
            <select name="role" value={form.role} onChange={handleChange}>
              <option value="patron">Patron</option>
              <option value="librarian">Librarian</option>
            </select>
            <span className="input-icon">📚</span>
          </div>
        )}

        <button onClick={handleSubmit} className="primary-button">
          {isLogin ? 'Login' : 'Register'}
        </button>

        {message && (
          <p className={`message ${message.includes('successful') ? 'success' : 'error'}`}>
            {message}
          </p>
        )}

        <div
          className="toggle-link"
          onClick={() => {
            setIsLogin(!isLogin);
            setMessage('');
            setForm({
              name: '',
              email: '',
              password: '',
              phone: '',
              address: '',
              dob: '',
              role: 'patron',
            });
          }}
        >
          {isLogin ? "Don't have an account? " : 'Already have an account? '}
          <span>{isLogin ? 'Sign up' : 'Login'}</span>
        </div>
      </div>

      {showLibrarianCodePrompt && (
        <div className="auth-card" style={{ marginTop: '1rem' }}>
          <h3>Enter Librarian Secret Code</h3>
          <div className="input-group">
            <input
              placeholder="Librarian Code"
              value={librarianCode}
              onChange={(e) => setLibrarianCode(e.target.value)}
            />
            <span className="input-icon">🔑</span>
          </div>
          <button onClick={verifyLibrarianCode} className="primary-button">
            Submit Code
          </button>
        </div>
      )}
    </div>
  );
}
