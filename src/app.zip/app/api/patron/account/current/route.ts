import { NextResponse } from 'next/server';
import Borrow from '@/app/models/borrow';
import connectDB from '@/app/lib/mongodb';

export async function GET(req: Request) {
  await connectDB();

  const { searchParams } = new URL(req.url);
  const userId = searchParams.get('userId');

  if (!userId) {
    return NextResponse.json({ error: 'Missing userId' }, { status: 400 });
  }

  const borrows = await Borrow.find({ userId, returnedAt: null }).populate('bookId');

  const currentBorrowed = borrows.map((b) => ({
    bookTitle: b.bookId.title,
    borrowedAt: b.borrowedAt,
    dueDate: b.dueDate,
  }));

  return NextResponse.json(currentBorrowed);
}
