import { NextRequest, NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';
import connectDB from '@/app/lib/mongodb'; 
import Borrow from '@/app/models/borrow'; 

export async function GET(req: NextRequest) {
  try {
    await connectDB();

    const token = req.cookies.get('token')?.value;

    if (!token) {
      return NextResponse.json({ success: false, message: 'Unauthorized: No token provided' }, { status: 401 });
    }

    if (!process.env.JWT_SECRET) {
      console.error('JWT_SECRET not defined in .env');
      return NextResponse.json({ success: false, message: 'Server configuration error' }, { status: 500 });
    }

    let decoded: any;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (jwtError) {
      console.error('JWT verification failed:', jwtError);
      return NextResponse.json({ success: false, message: 'Unauthorized: Invalid or expired token' }, { status: 401 });
    }

    const userId = decoded.id; 

 
    const history = await Borrow.find({ userId: userId })
      .populate({
        path: 'bookId',
        select: 'title author' 
      })
      .lean(); 

    const filteredHistory = history.filter(record => record.bookId !== null);

    return NextResponse.json({ success: true, history: filteredHistory });

  } catch (error: any) {
    console.error('API Error /api/patron/account/history:', error);
    return NextResponse.json({ success: false, message: 'Internal server error' }, { status: 500 });
  }
}