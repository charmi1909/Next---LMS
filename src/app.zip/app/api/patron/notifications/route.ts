
import { NextRequest, NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';
import connectDB from '@/app/lib/mongodb';
import Notification from '@/app/models/notification';

const JWT_SECRET = process.env.JWT_SECRET!;

export async function GET(req: NextRequest) {
  try {
    await connectDB();

    const token = req.cookies.get('token')?.value;
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized: No token' }, { status: 401 });
    }

    let decoded;
    try {
      decoded = jwt.verify(token, JWT_SECRET) as { id: string; email: string; role: string };
    } catch (err) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    if (decoded.role !== 'patron') {
      return NextResponse.json({ error: 'Access denied: Only patrons allowed' }, { status: 403 });
    }

    const notifications = await Notification.find({ userId: decoded.id }).sort({ createdAt: -1 });

    return NextResponse.json(notifications);
  } catch (err) {
    console.error('Notification fetch error:', err);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}
