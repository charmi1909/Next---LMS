import { NextResponse } from 'next/server';
import connectDB from '@/app/lib/mongodb';
import System from '@/app/models/system';

export async function GET() {
  try {
    await connectDB();

    let systemConfig = await System.findOne();
    if (!systemConfig) {
      systemConfig = new System();
      await systemConfig.save();
    }

    return NextResponse.json(systemConfig);
  } catch (error) {
    console.error('GET /api/system error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch system configuration' },
      { status: 500 }
    );
  }
}

export async function PUT(req: Request) {
  try {
    await connectDB();

    const data = await req.json();
    console.log('Received config to update:', data);

    const updatedConfig = await System.findOneAndUpdate(
      {},
      {
        borrowingLimit: data.borrowingLimit,
        fineRate: data.fineRate,
        loanPeriod: data.loanPeriod,
      },
      { new: true, upsert: true }
    );

    console.log('Updated system config:', updatedConfig);

    return NextResponse.json(updatedConfig);
  } catch (error) {
    console.error('PUT /api/system error:', error);
    return NextResponse.json(
      { error: 'Failed to update system configuration' },
      { status: 500 }
    );
  }
}
