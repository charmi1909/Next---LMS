import { NextResponse } from 'next/server';
import connectDB from '@/app/lib/mongodb';
import Borrow from '@/app/models/borrow';

const FINE_PER_DAY = 1; 

export async function GET(req: Request) {
  try {
    await connectDB();

    const { searchParams } = new URL(req.url);
    const patronId = searchParams.get('patronId');

    if (!patronId) {
      return NextResponse.json({ error: 'Missing patronId' }, { status: 400 });
    }

    const overdueBorrows = await Borrow.find({
      userId: patronId,
      returned: false,
      dueDate: { $lt: new Date() },
    });

    let totalFine = 0;
    const overdueDetails = overdueBorrows.map((borrow) => {
      const daysLate = Math.ceil((Date.now() - new Date(borrow.dueDate).getTime()) / (1000 * 60 * 60 * 24));
      const fine = daysLate * FINE_PER_DAY;
      totalFine += fine;
      return {
        bookId: borrow.bookId,
        dueDate: borrow.dueDate,
        daysLate,
        fine,
      };
    });

    return NextResponse.json({ totalFine, overdueDetails });
  } catch (err: any) {
    console.error('Fines API Error (GET):', err);
    return NextResponse.json({ error: 'Server error', details: err.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    await connectDB();

    const body = await req.json();
    const patronId = body.patronId;

    if (!patronId || typeof patronId !== 'string') {
      return NextResponse.json({ error: 'Invalid or missing patronId' }, { status: 400 });
    }

    const overdueBorrows = await Borrow.find({
      userId: patronId,
      returned: false,
      dueDate: { $lt: new Date() },
    });

    let totalFine = 0;

    for (const borrow of overdueBorrows) {
      const daysLate = Math.ceil((Date.now() - new Date(borrow.dueDate).getTime()) / (1000 * 60 * 60 * 24));
      const fine = daysLate * FINE_PER_DAY;
      totalFine += fine;

      borrow.fine = fine;
      borrow.fineCollected = true;
      await borrow.save();
    }

    return NextResponse.json({ success: true, totalFineCollected: totalFine });
  } catch (err: any) {
    console.error('Fines API Error (POST):', err);
    return NextResponse.json({ error: 'Server error', details: err.message }, { status: 500 });
  }
}
