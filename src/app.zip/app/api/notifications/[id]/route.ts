import { NextResponse } from 'next/server';
import connectDB from '@/app/lib/mongodb';
import Notification from '@/app/models/notification';

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  await connectDB();
  const updated = await Notification.findByIdAndUpdate(params.id, { read: true }, { new: true });
  return NextResponse.json(updated);
}

export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  await  connectDB ();
  await Notification.findByIdAndDelete(params.id);
  return NextResponse.json({ message: 'Deleted' });
}
