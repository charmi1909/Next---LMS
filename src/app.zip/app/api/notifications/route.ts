  import { NextResponse } from 'next/server';
  import connectDB from '@/app/lib/mongodb';
  import Notification from '@/app/models/notification';

  export async function GET() {
    await connectDB();
    const notifications = await Notification.find().sort({ createdAt: -1 });
    return NextResponse.json(notifications);
  }

  export async function POST(req: Request) {
    await connectDB();
    const { message, type } = await req.json();
    const notification = await Notification.create({ message, type });
    return NextResponse.json(notification, { status: 201 });
  }
