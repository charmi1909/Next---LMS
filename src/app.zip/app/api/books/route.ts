import { NextRequest, NextResponse } from "next/server";
import connectDB from "@/app/lib/mongodb";
import Book from "@/app/models/book";

export async function GET() {
  await connectDB();
  const books = await Book.find();
  return NextResponse.json({ success: true, data: books });
}

export async function POST(req: NextRequest) {
  await connectDB();
  const body = await req.json();

  try {
    const book = await Book.create(body);

    // 🚫 Remove Notification creation
    // await Notification.create({ ... });

    return NextResponse.json({ success: true, data: book }, { status: 201 });

  } catch (error: any) {
    // Handle duplicate ISBN error
    if (error.code === 11000) {
      return NextResponse.json(
        { success: false, message: "A book with this ISBN already exists." },
        { status: 400 }
      );
    }

    console.error("Book creation error:", error);
    return NextResponse.json(
      { success: false, message: "Book creation failed" },
      { status: 500 }
    );
  }
}
