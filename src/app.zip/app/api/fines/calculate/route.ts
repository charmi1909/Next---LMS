import { NextResponse } from 'next/server';
import connectDB from '@/app/lib/mongodb';
import Book from '@/app/models/book';
import Loan from '@/app/models/loan';


export async function POST(req: Request) {
    const { patronId } = await req.json();
    await connectDB();

    const today = new Date();
    const overdueLoans = await Loan.find({
        patronId,
        returned: false,
        dueDate: { $lt: today }
    });

    const finePerDay = 10;
    const totalFine = overdueLoans.reduce((sum, loan) => {
        const overdueDays = Math.ceil((today.getTime() - new Date(loan.dueDate).getTime()) / (1000 * 3600 * 24));
        return sum + (overdueDays * finePerDay);
    }, 0);

    return NextResponse.json({
        overdueCount: overdueLoans.length,
        totalFine
    });
}
