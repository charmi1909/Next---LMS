import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/app/lib/mongodb';
import Borrow from '@/app/models/borrow';
import Book from '@/app/models/book';
import Hold from '@/app/models/hold';
import Notification from '@/app/models/notification';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  await connectDB();

  try {
    const { id } = params;

    const borrow = await Borrow.findById(id).populate('bookId');
    if (!borrow || borrow.returned) {
      return NextResponse.json({ success: false, message: 'Invalid borrow record' }, { status: 404 });
    }

    const book = borrow.bookId;

    // ✅ Update borrow record
    borrow.returned = true;
    borrow.returnedAt = new Date();
    await borrow.save();

    // ✅ Update book availability
    book.availableCopies += 1;
    book.isAvailable = true; // <-- THIS LINE FIXES YOUR ISSUE
    await book.save();

    // ✅ Handle holds
    const nextHold = await Hold.findOne({
      bookId: book._id,
      status: 'pending',
    }).sort({ holdPlacedAt: 1 });

    if (nextHold) {
      nextHold.status = 'available';
      await nextHold.save();

      await Notification.create({
        userId: nextHold.userId,
        message: `The book "${book.title}" you placed on hold is now available.`,
        type: 'hold_available',
        read: false,
      });
    }

    return NextResponse.json({ success: true, message: 'Book returned successfully' });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ success: false, message: 'Return failed' }, { status: 500 });
  }
}
