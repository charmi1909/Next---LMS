import { NextResponse, NextRequest } from 'next/server';
import connectDB from '@/app/lib/mongodb';
import Borrow from '@/app/models/borrow';
import Book from '@/app/models/book'; 
import jwt from 'jsonwebtoken';

export async function GET(req: NextRequest) {
  try {
    await connectDB();

    const cookieHeader = req.headers.get('cookie') || '';
    const tokenMatch = cookieHeader.match(/token=([^;]+)/);
    const token = tokenMatch?.[1];

    if (!token) {
      return NextResponse.json({ error: 'Unauthorized: No token' }, { status: 401 });
    }

    const secret = process.env.JWT_SECRET;
    if (!secret) {
      return NextResponse.json({ error: 'JWT_SECRET not set in environment' }, { status: 500 });
    }

    const decoded = jwt.verify(token, secret) as { id: string };
    const userId = decoded.id;

    const borrows = await Borrow.find({ userId, returned: false })
      .populate({
        path: 'bookId',
        select: 'title author'
      });

    const fineRatePerDay = 2; 
    const today = new Date();

    const enrichedBorrows = borrows.map(borrow => {
      const dueDate = new Date(borrow.dueDate);
      let fine = 0;

      if (today > dueDate) {
        const overdueDays = Math.ceil((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));
        fine = overdueDays * fineRatePerDay;
      }

      return {
        ...borrow.toObject(),
        fine,
      };
    });

    return NextResponse.json(enrichedBorrows);

  } catch (error: any) {
    console.error('Borrow current error:', error);

    if (error instanceof jwt.JsonWebTokenError) {
      return NextResponse.json({ error: 'Invalid or expired token' }, { status: 401 });
    }

    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
