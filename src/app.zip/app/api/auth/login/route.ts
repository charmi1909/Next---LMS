// /api/auth/login/route.ts
import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import connectDB from '@/app/lib/mongodb';
import User from '@/app/models/user';
import Notification from '@/app/models/notification';

export async function POST(req: Request) {
  try {
    await connectDB();

    const { email, password } = await req.json();

    if (!email || !password) {
      return NextResponse.json({ error: 'Email and password are required.' }, { status: 400 });
    }

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      return NextResponse.json({ error: 'User not found.' }, { status: 404 });
    }

    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
      return NextResponse.json({ error: 'Invalid password.' }, { status: 401 });
    }

    if (!process.env.JWT_SECRET) {
      return NextResponse.json({ error: 'JWT secret not configured.' }, { status: 500 });
    }

    const token = jwt.sign(
      {
        id: user._id.toString(),
        email: user.email,
        role: user.role,
        name: user.name,
      },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    // Optional: Notify when librarian logs in
    if (user.role === 'librarian') {
      await Notification.create({
        message: `${user.name} (Librarian) logged in.`,
        type: 'login',
        userId: user._id,
      });
    }

    const response = NextResponse.json(
      {
        message: 'Login successful!',
        user: {
          id: user._id,
          email: user.email,
          role: user.role,
          name: user.name,
        },
      },
      { status: 200 }
    );

    response.cookies.set('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      maxAge: 60 * 60 * 24,
    });

    return response;
  } catch (err: any) {
    console.error('Login Error:', err.message, err.stack);
    return NextResponse.json({ error: 'Server error. Please try again.' }, { status: 500 });
  }
}
