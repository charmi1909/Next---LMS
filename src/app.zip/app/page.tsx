// src/app/page.tsx
import Link from "next/link";
import "./globals.css";

export default function HomePage() {
  return (
    <main className="hero">
      <div className="hero-content animate-in">
        <h1>📚 Welcome to <span className="highlight">Library Management System</span></h1>
        <p>🚀 Manage books, patrons, and circulation with ease and elegance.</p>
        <Link href="/auth" passHref>
          <button className="join-now-button">✨ Join Now</button>
        </Link>
      </div>
    </main>
  );
}
