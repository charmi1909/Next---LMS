import mongoose, { Schema, model, models } from 'mongoose';

const BorrowSchema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  bookId: { type: Schema.Types.ObjectId, ref: 'Book', required: true },
  borrowedAt: { type: Date, default: Date.now },
  dueDate: { type: Date, required: true },
  returned: { type: Boolean, default: false }, // ✅ Add this
  returnedAt: { type: Date, default: null },   // ✅ Corrected field
}, {
  timestamps: true // adds createdAt and updatedAt automatically
});

const Borrow = models.Borrow || model('Borrow', BorrowSchema);
export default Borrow;
