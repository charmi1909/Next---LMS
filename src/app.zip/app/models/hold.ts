import mongoose, { Schema, Document } from 'mongoose';

export interface IHold extends Document {
  userId: mongoose.Types.ObjectId;
  bookId: mongoose.Types.ObjectId;
  holdPlacedAt: Date;
  status: 'pending' | 'available' | 'fulfilled' | 'cancelled';
}

const HoldSchema: Schema = new Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  bookId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Book',
    required: true,
  },
  holdPlacedAt: {
    type: Date,
    default: Date.now,
  },
  status: {
    type: String,
    enum: ['pending', 'available', 'fulfilled', 'cancelled'],
    default: 'pending',
  },
}, {
  timestamps: true,
});

const Hold = mongoose.models.Hold || mongoose.model<IHold>('Hold', HoldSchema);
export default Hold;
