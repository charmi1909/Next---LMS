import mongoose from 'mongoose';

const bookSchema = new mongoose.Schema({
  title: String,
  author: String,
  description: String,
  isbn: String,
  subject: String,
  keywords: [String],
  type: {
    type: String,
    enum: ['book', 'magazine', 'novel', 'journal', 'reference', 'textbook'],
    required: true,
  },
  isAvailable: { type: Boolean, default: false },
  location: String,
}, { timestamps: true });

const Book = mongoose.models.Book || mongoose.model('Book', bookSchema);
export default Book;
